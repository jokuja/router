
public class Stat {
	int all;
    int ip;
    public int getAll() {
		return all;
	}

	public void setAll(int all) {
		this.all = all;
	}
	int arp;

    int icmp;
    int udp;
    int tcp;
    
    int http;
    int ssh;
    int ftp;
    
    public Stat () {
        ip= 0;
        arp = 0;
        icmp = 0;
        udp=0;
        tcp=0;
        http=0;
        ssh=0;
        ftp=0;
        all=0;
    }
    
	public int getIp() {
		return ip;
	}
	public void setIp(int ip) {
		this.ip = ip;
	}
	public int getArp() {
		return arp;
	}
	public void setArp(int arp) {
		this.arp = arp;
	}
	public int getIcmp() {
		return icmp;
	}
	public void setIcmp(int icmp) {
		this.icmp = icmp;
	}
	public int getUdp() {
		return udp;
	}
	public void setUdp(int udp) {
		this.udp = udp;
	}
	public int getTcp() {
		return tcp;
	}
	public void setTcp(int tcp) {
		this.tcp = tcp;
	}
	public int getHttp() {
		return http;
	}
	public void setHttp(int http) {
		this.http = http;
	}
	public int getSsh() {
		return ssh;
	}
	public void setSsh(int ssh) {
		this.ssh = ssh;
	}
	public int getFtp() {
		return ftp;
	}
	public void setFtp(int ftp) {
		this.ftp = ftp;
	}

}


