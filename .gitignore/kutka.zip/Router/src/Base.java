	import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.sql.Time;

import org.jnetpcap.Pcap;
import org.jnetpcap.PcapIf;
import org.jnetpcap.nio.JBuffer;
import org.jnetpcap.packet.JPacket;
import org.jnetpcap.packet.PcapPacket;
import org.jnetpcap.packet.PcapPacketHandler;
import org.jnetpcap.protocol.lan.Ethernet;
import org.jnetpcap.protocol.network.Arp;
import org.jnetpcap.protocol.network.Ip4;
import org.jnetpcap.protocol.tcpip.Tcp;

import java.util.*;
import java.lang.*;

import javax.swing.JButton;
import javax.swing.JFrame;


import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;

import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
//vlakna info http://www.algoritmy.net/article/39287/Vlakna-22
public class Base {

	static  Hashtable<String,Arp_riadok> arp = new Hashtable<String,Arp_riadok>(); //hash podla ip adresy
	static  Hashtable<String,Cam_riadok> cam = new Hashtable<String,Cam_riadok>();	
	static  Hashtable<String,Rt_riadok> rt = new Hashtable<String,Rt_riadok>();	//hash podla ip adresy
	
	public static final int ETHERNET_TYPE_OFFSET = 12;
	public static final int IP_TYPE_OFFSET = 23;
	public static final int TCP_TYPE_OFFSET = 34;
	public static final int ETHERNET_TYPE_IP = 0x800;
	public static final int ETHERNET_TYPE_ARP = 0x806;
	

	static List zasobnik = new ArrayList();
	private List list = new ArrayList();
	static Stat[] statpole1 = new Stat[3]; // pole statistik 
	static Stat[] statpole2 = new Stat[3]; // pole statistik 
	
public static void main(String[] args) throws InterruptedException, IOException {

	
	//promenne vyuzivane ve vnitrnich tridach musi byt konecne (final)
	
final Base m = new Base(); //vytvorime instanci objektu Main (kvuli seznamu list)

List<PcapIf> alldevs = new ArrayList<PcapIf>(); // Will be filled with NICs
StringBuilder errbuf = new StringBuilder(); // For any error msgs

int r = Pcap.findAllDevs(alldevs, errbuf);
if (r == Pcap.NOT_OK || alldevs.isEmpty()) {
	System.err.printf("Can't read list of devices, error is %s", errbuf
	    .toString());
	return;
}
//vypise sietove zariadenia
System.out.println("Network devices found:");	
	int i = 0;
	for (PcapIf device : alldevs) {
		String description =
		    (device.getDescription() != null) ? device.getDescription()
		        : "No description available";
		    System.out.printf("#%d: %s [%s] %s\n", i++, device.getName(), description, asString(device.getHardwareAddress()));
	}	
	
	//sem vybrat ktore rozhrania chcem
	System.out.printf("\nChoose 2 interfaces and write their numbers:");
	Scanner in = new Scanner(System.in);
	int prve = in.nextInt();
	int druhe = in.nextInt();
	
	PcapIf device1 = alldevs.get(prve); // We know we have atleast 1 device
	System.out
	    .printf("\nChoosing '%s' on your behalf:\n",
	        (device1.getDescription() != null) ? device1.getDescription()
	            : device1.getName());
	
	int snaplen = 64 * 1024;           // Capture all packets, no trucation
	int flags = Pcap.MODE_PROMISCUOUS; // capture all packets
	int timeout = 100;           // 10 seconds in millis

	Pcap pcap1 = Pcap.openLive(device1.getName(), snaplen, flags, timeout, errbuf);

	if (pcap1 == null) {        
		System.err.printf("Error while opening device for capture: "
		    + errbuf.toString());
		return;
	}
	
	Arp_riadok apom = new Arp_riadok();//prida info o rozhrani do arp table//este treba pridat aj do routing table
	 apom.mac=device1.getHardwareAddress();
	 apom.roz=1;
	 apom.typ=11;
	 byte[] bytes = { 1, 1, 1, 2 };
	 apom.setIp( bytes );
	 arp.put(asString(apom.ip),apom);
	 System.out.printf("vlozena ip1  %s \n",asString(apom.ip)); 
	
	 Rt_riadok rpom = new Rt_riadok();//napriklad natvrdo maska 24
	 rpom.setMask(24);
	 rpom.setIp(bytes);//vynulovat podla masky
	 rpom.setRoz(1);
	 rpom.setTyp(11);
	 
	 rt.put(asString(rpom.ip), rpom);
	 
	 
	//otvori rozhranie 2 , co je virtualka a tam vsetk0 budem posielat 
	PcapIf device2 = alldevs.get(druhe); // We know we have atleast 1 device
	System.out
	    .printf("\nChoosing '%s' on your behalf:\n",
	        (device2.getDescription() != null) ? device2.getDescription()
	            : device2.getName());

	Pcap pcap2 = Pcap.openLive(device2.getName(), snaplen, flags, timeout, errbuf);

	if (pcap2 == null) {
		System.err.printf("Error while opening device for capture: "
		    + errbuf.toString());
		return;
	}
	
	Arp_riadok apom2 = new Arp_riadok();//prida info o rozhrani do arp table//este treba pridat aj do routing table
	 apom2.mac=device2.getHardwareAddress();
	 apom2.roz=2;
	 apom2.typ=11;
	 byte[] bytes2 = { 2, 2, 2, 1 };
	 apom2.setIp( bytes2 );
	 arp.put(asString(apom2.ip),apom2);
	 System.out.printf("vlozena ip2  %s \n",asString(apom2.ip)); 
	
	 Rt_riadok rpom2 = new Rt_riadok();//napriklad natvrdo maska 24
	 rpom2.setMask(24);
	 rpom2.setIp(bytes2);//vynulovat podla masky
	 rpom2.setRoz(2);
	 rpom2.setTyp(11);
	 
	 rt.put(asString(rpom2.ip), rpom2);
	

	for(int j=0; j<=2;j++)
	{
		 statpole1[j] = new Stat();
		 statpole2[j] = new Stat();
	}			
	
Thread t1 = new Thread() {
@Override
//ty bezi prve vlakno
public void run() {
	
//synchronized (m) {
	posli(pcap1,pcap2,1); //nacitava, posiela, uklada,interface
}
//}
};

Thread t2 = new Thread() {

@Override
//ty bezi druhe vlakno
public void run() {

//synchronized (m) {
	posli(pcap2,pcap1,2);//nacitava, posiela, uklada, interface
}
//}
};
Thread t3 = new Thread()
{
	@Override
public void run(){
		//synchronized (m) {

		info( pcap1,pcap2,apom,apom2);
		}
//}
};

Thread t4 = new Thread()
{
	@Override
public void run(){
	//	synchronized (m) {
	try {
		stat();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	//}
}
	}
};



t3.start();
t1.start();
t2.start();
t4.start();
}

//tu uz len metody ktore neviem dat do inej classy---------------------------------------------------

private static String asString(final byte[] mac) {  
    final StringBuilder buf = new StringBuilder();  
    for (byte b : mac) {  
      if (buf.length() != 0) {  
        buf.append(':');  
      }  
      if (b >= 0 && b < 16) {  
        buf.append('0');  
      }  
      buf.append(Integer.toHexString((b < 0) ? b + 256 : b).toUpperCase());  
    }  
    return buf.toString();  
  } 
//******************************************************************************************
public static int toInt(byte[] bytes, int offset) {
	  int ret = 0;
	  for (int i=0; i<4 && i+offset<bytes.length; i++) {
	    ret <<= 8;
	    ret |= (int)bytes[i] & 0xFF;
	  }
	  return ret;
	}
/////////////////////////////////

private static void delarp() {  
   
	while(true){
		Scanner in = new Scanner(System.in);
		int nula = in.nextInt();
		
		if ( nula == 0)
			System.out.printf("delcam\n");

	try
	{
		Thread.sleep(5000);
	} catch (InterruptedException ee)
	{
		// TODO Auto-generated catch block
		ee.printStackTrace();
	}
	}
} 

private static void pocita1(PcapPacket packet,int smer) { //statpole[port][smer]
	byte[] etherType = packet.getByteArray(ETHERNET_TYPE_OFFSET, 2); 
	
	if (etherType[0] == 0x08 )
	{
		statpole1[smer].all=statpole1[smer].all+1;
		
		if(etherType[1] == 0x00)//IPv4
		{
			//statpole[port][smer].setIp(statpole[port][smer].getIp() + 1);
			statpole1[smer].ip=statpole1[smer].ip+1;
			
			byte[] ipType = packet.getByteArray(IP_TYPE_OFFSET, 2); 
				
			if(ipType[0] == 0x11)//UDP
			{
				//statpole[port][smer].setUdp(statpole[port][smer].getUdp() + 1);	
				statpole1[smer].udp=statpole1[smer].udp+1;
			}
			
			if(ipType[0] == 0x01)//ICMP
			{
				//statpole[port][smer].setIcmp(statpole[port][smer].getIcmp() + 1);	
				statpole1[smer].icmp=statpole1[smer].icmp+1;
			}
			
			if(ipType[0] == 0x06)//TCP
			{
				//statpole[port][smer].setTcp(statpole[port][smer].getTcp() + 1);	
				statpole1[smer].tcp=statpole1[smer].tcp+1;
				
				byte[] tcpType = packet.getByteArray(TCP_TYPE_OFFSET, 4);
				
				if((tcpType[0] == 0x00  && tcpType[1] == 0x50 ) || (tcpType[2] == 0x00  && tcpType[3] == 0x50 ) ) //http
				{
					//statpole[port][smer].setHttp(statpole[port][smer].getHttp() + 1);
					statpole1[smer].http=statpole1[smer].http+1;
				}	
				
				if((tcpType[0] == 0  && tcpType[1] == 20 ) || (tcpType[2] == 0  && tcpType[3] == 20 ) ) //ftp1
				{
					//statpole[port][smer].setFtp(statpole[port][smer].getFtp() + 1);
					statpole1[smer].ftp=statpole1[smer].ftp+1;
				}
				
				if((tcpType[0] == 1  && tcpType[1] == 21 ) || (tcpType[2] == 0  && tcpType[3] == 21 ) ) //ftp2
				{
					//statpole[port][smer].setFtp(statpole[port][smer].getFtp() + 1);
					statpole1[smer].ftp=statpole1[smer].ftp+1;
				}
				
				if((tcpType[0] == 1  && tcpType[1] == 22 ) || (tcpType[2] == 0  && tcpType[3] == 22 ) ) //ssh
				{
					//statpole[port][smer].setSsh(statpole[port][smer].getSsh() + 1);
					statpole1[smer].ssh=statpole1[smer].ssh+1;
				}	
			}				
		}	
		if(etherType[1] == 0x06)//ARP
		{
			statpole1[smer].setArp(statpole1[smer].getArp() + 1);
		}	
	}
  } 
//******************************************************************************************


private static void pocita2(PcapPacket packet, int smer) { //statpole[port][smer]
	byte[] etherType = packet.getByteArray(ETHERNET_TYPE_OFFSET, 2); 
	
	if (etherType[0] == 0x08 )
	{
		statpole2[smer].all=statpole2[smer].all+1;
		
		if(etherType[1] == 0x00)//IPv4
		{
			//statpole[port][smer].setIp(statpole[port][smer].getIp() + 1);
			statpole2[smer].ip=statpole2[smer].ip+1;
			
			byte[] ipType = packet.getByteArray(IP_TYPE_OFFSET, 2); 
				
			if(ipType[0] == 0x11)//UDP
			{
				//statpole[port][smer].setUdp(statpole[port][smer].getUdp() + 1);	
				statpole2[smer].udp=statpole2[smer].udp+1;
			}
			
			if(ipType[0] == 0x01)//ICMP
			{
				//statpole[port][smer].setIcmp(statpole[port][smer].getIcmp() + 1);	
				statpole2[smer].icmp=statpole2[smer].icmp+1;
			}
			
			if(ipType[0] == 0x06)//TCP
			{
				//statpole[port][smer].setTcp(statpole[port][smer].getTcp() + 1);	
				statpole2[smer].tcp=statpole2[smer].tcp+1;
				
				byte[] tcpType = packet.getByteArray(TCP_TYPE_OFFSET, 4);
				
				if((tcpType[0] == 0x00  && tcpType[1] == 0x50 ) || (tcpType[2] == 0x00  && tcpType[3] == 0x50 ) ) //http
				{
					//statpole[port][smer].setHttp(statpole[port][smer].getHttp() + 1);
					statpole2[smer].http=statpole2[smer].http+1;
				}	
				
				if((tcpType[0] == 0  && tcpType[1] == 20 ) || (tcpType[2] == 0  && tcpType[3] == 20 ) ) //ftp1
				{
					//statpole[port][smer].setFtp(statpole[port][smer].getFtp() + 1);
					statpole2[smer].ftp=statpole2[smer].ftp+1;
				}
				
				if((tcpType[0] == 1  && tcpType[1] == 21 ) || (tcpType[2] == 0  && tcpType[3] == 21 ) ) //ftp2
				{
					//statpole[port][smer].setFtp(statpole[port][smer].getFtp() + 1);
					statpole2[smer].ftp=statpole2[smer].ftp+1;
				}
				
				if((tcpType[0] == 1  && tcpType[1] == 22 ) || (tcpType[2] == 0  && tcpType[3] == 22 ) ) //ssh
				{
					//statpole[port][smer].setSsh(statpole[port][smer].getSsh() + 1);
					statpole2[smer].ssh=statpole2[smer].ssh+1;
				}	
			}				
		}	
		if(etherType[1] == 0x06)//ARP
		{
			statpole2[smer].setArp(statpole2[smer].getArp() + 1);
		}	
	}
  } 
//**************************

private static void stat() throws UnsupportedEncodingException, FileNotFoundException, IOException
{
	
	while(true){
		// System.out.printf("stat ide\n");
	File file = new File("stat.txt");
	FileWriter fw = new FileWriter(file);
	PrintWriter pw = new PrintWriter(fw);
	
	pw.println("Port1 in/out \n");
		for(int j=1; j<=2;j++)
{
			String all=String.valueOf(statpole1[j].all);
			String arp=String.valueOf(statpole1[j].arp);
			String ip=String.valueOf(statpole1[j].ip);			
			String tcp=String.valueOf(statpole1[j].tcp);
			String icmp=String.valueOf(statpole1[j].icmp);
			String udp=String.valueOf(statpole1[j].udp);
			String ftp=String.valueOf(statpole1[j].ftp);
			String ssh=String.valueOf(statpole1[j].ssh);
			String http=String.valueOf(statpole1[j].http);

			pw.println("all "+all);			
			pw.println("arp "+arp);
			pw.println("ipv4 "+ip);
			pw.println("tcp "+tcp);
			pw.println("icmp "+icmp);
			pw.println("udp "+udp);
			pw.println("ftp "+ftp);
			pw.println("ssh "+ssh);
			pw.println("http "+http+"\n");
		}
		
		pw.println("\nPort2 in/out \n");
		for(int j=1; j<=2;j++)
		{
			String all=String.valueOf(statpole2[j].all);
			String arp=String.valueOf(statpole2[j].arp);
			String ip=String.valueOf(statpole2[j].ip);			
			String tcp=String.valueOf(statpole2[j].tcp);
			String icmp=String.valueOf(statpole2[j].icmp);
			String udp=String.valueOf(statpole2[j].udp);
			String ftp=String.valueOf(statpole2[j].ftp);
			String ssh=String.valueOf(statpole2[j].ssh);
			String http=String.valueOf(statpole2[j].http);

			pw.println("all "+all);	
			pw.println("arp "+arp);
			pw.println("ipv4 "+ip);
			pw.println("tcp "+tcp);
			pw.println("icmp "+icmp);
			pw.println("udp "+udp);
			pw.println("ftp "+ftp);
			pw.println("ssh "+ssh);
			pw.println("http "+http+"\n");
		}
		pw.close();
		
		try
		{
			Thread.sleep(5000);
		} catch (InterruptedException ee)
		{
			// TODO Auto-generated catch block
			ee.printStackTrace();
		}}
}
private static int filter(PcapPacket packet, int cislo,int smer) throws FileNotFoundException, IOException
{
	String subor=null;
	
	if (cislo == 1)	
	{
		if(smer == 1 )//in
			subor="1in.txt";
		else
			subor="1out.txt";
	}
	
	if (cislo == 2) 
	{
		if(smer == 1 )//in
			subor="2in.txt";
		else
			subor="2out.txt";
	}
	

try(BufferedReader br = new BufferedReader(new FileReader(subor))) {//otvori filter file
		
	byte[] destmac = packet.getByteArray(0, 6); 
	byte[] sourcemac = packet.getByteArray(6, 6); 	
		
		String fdmac = br.readLine();
		String fsmac = br.readLine();
		String fdip = br.readLine();
		String fsip = br.readLine();
		String fip = br.readLine();
		String farp = br.readLine();
		String ftcp = br.readLine();
		String fudp = br.readLine();
		String ficmp = br.readLine();
		String fhttp = br.readLine();
		String ftelnet = br.readLine();
		String fssh = br.readLine();
		String frip = br.readLine();
		String fftp = br.readLine();
		
		String vlastne = br.readLine();
		
		
	
	if(!(Objects.equals(fdmac, "destmac ")))//tu mac mozme osetrit hned
	{
		if(!(Objects.equals(fdmac, "destmac "+asString(destmac))))
		{
			//System.out.printf("filter <%s> ramec <%s>\n",fdmac,asString(destmac));
			return 0;
		}
	}
	
	if(!(Objects.equals(fsmac, "sourcemac ")))//tu mac mozme osetrit hned
	{
		if(!(Objects.equals(fsmac, "sourcemac "+asString(sourcemac))))
		{
			//System.out.printf("filter <%s> ramec <%s>\n",fsmac,asString(sourcemac));
			return 0;
		}
	}
	
	byte[] etherType = packet.getByteArray(ETHERNET_TYPE_OFFSET, 2); 
	
	if (etherType[0] == 0x08 )
	{
		if(etherType[1] == 0x00)//IPv4
		{
//ipecky zaciatok

			Ip4 ip = new Ip4();
			byte[] sIP = new byte[4];
			byte[] dIP = new byte[4];
			String sourceIP="";
			String destIP="";
			   //sIP = packet.getHeader(ip).source();//chyby takze radsej rucne nacitat
			   sIP = packet.getByteArray(26, 4);
			   sourceIP = org.jnetpcap.packet.format.FormatUtils.ip(sIP);
			   //dIP = packet.getHeader(ip).destination();
			   dIP = packet.getByteArray(30, 4);
			   destIP = org.jnetpcap.packet.format.FormatUtils.ip(dIP);


			   
				if(!(Objects.equals(fsip, "sourceip ")))///ak zadana nejaka hodnota ip
				{
					if(!(Objects.equals(fsip, "sourceip "+sourceIP)))
					{
						   System.out.printf("1filter <%s> ramec <%s>\n",fsip,sourceIP);
						return 0;
					}
				}
	
				if(!(Objects.equals(fdip, "destip ")))//ak zadana nejaka hodnota ip
				{
					if(!(Objects.equals(fdip, "destip "+destIP)))
					{
						System.out.printf("1filter <%s> ramec <%s>\n",fdip,destIP);	
						return 0;
					}
				}
			//ipecky koniec	
			   
			if (Objects.equals(fip,"ip 0")) return 0;
			
			byte[] ipType = packet.getByteArray(IP_TYPE_OFFSET, 2); 
			
			if(ipType[0] == 0x11)//UDP
			{
				if (Objects.equals(fudp,"udp 0")) return 0;
				
			}
			
			if(ipType[0] == 0x01)//ICMP
			{
				if (Objects.equals(ficmp,"icmp 0")) return 0;
			}
			
			if(ipType[0] == 0x06)//TCP
			{
				if (Objects.equals(ftcp,"tcp 0")) return 0;
				byte[] tcpType = packet.getByteArray(TCP_TYPE_OFFSET, 4);
				byte[] tcp1 = packet.getByteArray(TCP_TYPE_OFFSET, 2);
				byte[] tcp2 = packet.getByteArray(TCP_TYPE_OFFSET+2, 2);
				
				
				if((tcpType[0] == 0x00  && tcpType[1] == 0x50 ) || (tcpType[2] == 0x00  && tcpType[3] == 0x50 ) ) //http
				{
					if (Objects.equals(fhttp,"http 0")) return 0;
				}	
				
				if((tcpType[0] == 0  && tcpType[1] == 20 ) || (tcpType[2] == 0  && tcpType[3] == 20 ) ) //ftp1
				{
					if (Objects.equals(fftp,"ftp 0")) return 0;
				}
				
				if((tcpType[0] == 1  && tcpType[1] == 21 ) || (tcpType[2] == 0  && tcpType[3] == 21 ) ) //ftp2
				{
					if (Objects.equals(fftp,"ftp 0")) return 0;
				}
				
				if((tcpType[0] == 1  && tcpType[1] == 22 ) || (tcpType[2] == 0  && tcpType[3] == 22 ) ) //ssh
				{
					if (Objects.equals(fssh,"ssh 0")) return 0;
				}
				
			//	System.out.printf("ramec <%s %s> subor <%s>\n",Integer.toString(toInt(tcp1,0)),Integer.toString(toInt(tcp2,0)),vlastne);
				
				if( Integer.toString(toInt(tcp1,0)).equals(vlastne)  || Integer.toString(toInt(tcp2,0)).equals(vlastne)   ) //vlastne
				{
				//	System.out.printf("blokovanyvlastny port\n");
					return 0;
				}	
				
			}
		}
		if(etherType[1] == 0x06)//arp
		{
			 Arp arp = new Arp();
				byte[] sIP = new byte[4];
				byte[] dIP = new byte[4];
				String sourceIP="";
				String destIP="";

					sIP = packet.getByteArray(28, 4);
				   sourceIP = org.jnetpcap.packet.format.FormatUtils.ip(sIP);
				  
				   sIP = packet.getByteArray(38, 4);
				   destIP = org.jnetpcap.packet.format.FormatUtils.ip(dIP);

					if(!(Objects.equals(fsip, "sourceip ")))///ak zadana nejaka hodnota ip
					{
						if(!(Objects.equals(fsip, "sourceip "+sourceIP)))
						{
							System.out.printf("1arp filter <%s> ramec <%s>\n",fsip,sourceIP);
							return 0;
						}
					}

					if(!(Objects.equals(fdip, "destip ")))//ak zadana nejaka hodnota ip
					{
						if(!(Objects.equals(fdip, "destip "+destIP)))
						{
							System.out.printf("1arp filter <%s> ramec <%s>\n",fdip,destIP);	
							return 0;
						}
					}
				
				if (Objects.equals(farp,"arp 0")) return 0;
		}
	}			
		br.close();
	}//koniec filter file
	return 1;
}

private static void arp(Pcap roz1, Pcap roz2, Arp_riadok apom, Arp_riadok apom2)
{
	
	byte[] data = new byte[60];
	Arrays.fill( data, (byte) 0 );
	
	System.out.printf("posiela ARP"); 
	   data[0]=(byte) 0xff;	//dest mac is source mac of pakcet
	   data[1]=(byte) 0xff;
	   data[2]=(byte) 0xff;
	   data[3]=(byte) 0xff;
	   data[4]=(byte) 0xff;
	   data[5]=(byte) 0xff;
	   
	   //pre rozhranie 1
	   
	   byte[] ipecka = apom.ip;
	   byte[] macad = apom.mac;
	   data[6]=macad[0];	//macad is MAC of interface
	   data[7]=macad[1];
	   data[8]=macad[2];
	   data[9]=macad[3];
	   data[10]=macad[4];
	   data[11]=macad[5];	
	   
	   data[12]=(byte) 0x08;	   
	   data[13]=(byte) 0x06;
	   data[14]=(byte) 0x00;	   
	   data[15]=(byte) 0x01;
	   data[16]=(byte) 0x08;	   
	   data[17]=(byte) 0x00;
	   data[18]=(byte) 0x06;	   
	   data[19]=(byte) 0x04;
	   data[20]=(byte) 0x00;
	   data[21]=01; //arp request	
	   
	   data[22]=macad[0];	
	   data[23]=macad[1];	
	   data[24]=macad[2];	
	   data[25]=macad[3];
	   data[26]=macad[4];
	   data[27]=macad[5];
	   
	   data[28]=ipecka[0];
	   data[29]=ipecka[1]; 
	   data[30]=ipecka[2];
	   data[31]=ipecka[3];
	   
	   data[32]=0;	
	   data[33]=0;	
	   data[34]=0;	
	   data[35]=0;	
	   data[36]=0;
	   data[37]=0;
	   
	   data[38]=1;//adresa kam chcem pingat
	   data[39]=1; 
	   data[40]=1;
	   data[41]=1;
	   
	 String  spacket= asString(data);
       zasobnik.add(spacket);	
    
    if (roz1.sendPacket(data) != Pcap.OK) {  
		      System.err.println(roz1.getErr());  
		    } 
    
	   //pre rozhranie 2
    
	   ipecka = apom2.ip;
	   macad = apom2.mac;
	   data[6]=macad[0];	//macad is MAC of interface
	   data[7]=macad[1];
	   data[8]=macad[2];
	   data[9]=macad[3];
	   data[10]=macad[4];
	   data[11]=macad[5];	
	   
	   data[12]=(byte) 0x08;	   
	   data[13]=(byte) 0x06;
	   data[14]=(byte) 0x00;	   
	   data[15]=(byte) 0x01;
	   data[16]=(byte) 0x08;	   
	   data[17]=(byte) 0x00;
	   data[18]=(byte) 0x06;	   
	   data[19]=(byte) 0x04;
	   data[20]=(byte) 0x00;
	   data[21]=01; //arp request	
	   
	   data[22]=macad[0];	
	   data[23]=macad[1];	
	   data[24]=macad[2];	
	   data[25]=macad[3];
	   data[26]=macad[4];
	   data[27]=macad[5];
	   
	   data[28]=ipecka[0];
	   data[29]=ipecka[1]; 
	   data[30]=ipecka[2];
	   data[31]=ipecka[3];
	   
	   data[32]=0;	
	   data[33]=0;	
	   data[34]=0;	
	   data[35]=0;	
	   data[36]=0;
	   data[37]=0;
	   
	   data[38]=1;//adresa kam chcem pingat
	   data[39]=1; 
	   data[40]=1;
	   data[41]=1;   
	   
	   spacket= asString(data);
       zasobnik.add(spacket);	
	   
	    if (roz2.sendPacket(data) != Pcap.OK) {  
		      System.err.println(roz2.getErr());  
		    } 
}


private static void posli(Pcap roz1, Pcap roz2,int cislo )
{
PcapPacketHandler<String> jpacketHandler = new PcapPacketHandler<String>() {
		
	public void nextPacket(PcapPacket packet, String user) {
			
	String spacket = new String(packet.getByteArray(0, packet.getCaptureHeader().caplen()), StandardCharsets.UTF_8);
	byte[] data = packet.getByteArray(0, packet.size());
	
	
	byte[] ramecType = packet.getByteArray(12, 2);
	byte[] ipType = packet.getByteArray(14, 1);
	

	if (toInt(ramecType,0) > 1500) 
	if(toInt(ipType,0)< 96)
	{
	if (zasobnik.contains(spacket) == false)
	{	
		byte[] etherType = packet.getByteArray(ETHERNET_TYPE_OFFSET, 2); 
		
		if (etherType[0] == 0x08 )
		{
			if(etherType[1] == 0x06)//ARP
			{
				
		
				byte[] sIP = new byte[4];
				byte[] dIP = new byte[4];

				byte[] sMAC = new byte[6];
				byte[] dMAC = new byte[6];
				
				byte[] typ = new byte[1];
				
				String sourceIP="";
				String destIP="";
				String sourceMAC="";
				String destMAC="";
				String typp="";
				
				   sIP = packet.getByteArray(28, 4);
				   sourceIP = org.jnetpcap.packet.format.FormatUtils.ip(sIP);
				//   System.out.printf("sIP %s\n",sourceIP);
				  
				   dIP = packet.getByteArray(38, 4);
				   destIP = org.jnetpcap.packet.format.FormatUtils.ip(dIP);
				//   System.out.printf("dIP %s\n\n",destIP);
				   
				   sMAC = packet.getByteArray(6, 6);
				   sourceMAC = asString(sMAC);
				//   System.out.printf("MAC %s\n",sourceMAC);
				   
				   dMAC = packet.getByteArray(0, 6);
				   destMAC = asString(dMAC);
				//   System.out.printf("dMAC %s\n\n",destMAC);
								
				   typ = packet.getByteArray(21, 1);
				   typp = asString(typ);
		
				   Arp_riadok tmp = new Arp_riadok();
				   
				   tmp=arp.get(asString(sIP));
				   
				   if(typp.equals("02"))//pridaj do arp_table
				   {
					  // System.out.printf("	prislo arp reply\n");  
					   if ( ! dIP.equals(sIP)){
					   if (tmp == null){
					   Arp_riadok apom = new Arp_riadok();
						//get mac 
					   apom.mac=sMAC;
						 apom.roz=cislo;
						 apom.typ=1;
						 //get ip 
						 byte[] bytes = sIP;
						 apom.setIp( bytes );
						 arp.put(asString(apom.ip),apom);
					//	 System.out.printf("add %s \n\n",asString(bytes));						 
					   }
				   }}
				   
				   if(typp.equals("01"))//check if there is desired ip in our arp_table and reply
				   {   	
					   if ( ! dIP.equals(sIP)){				   
				   
					   if (tmp == null)
					   {
						   Arp_riadok apom = new Arp_riadok();
							//get mac 
						   apom.mac=sMAC;
							 apom.roz=cislo;
							 apom.typ=1;
							 //get ip 
							 byte[] bytes = sIP;
							 apom.setIp( bytes );
							 arp.put(asString(apom.ip),apom);
					//		 System.out.printf("add %s \n\n",asString(bytes));
					   }}			
					  // System.out.printf("hladana ip  %s \n",asString(dIP)); 
					   
					   tmp=arp.get(asString(dIP));
					   
					   if (tmp != null)//tu treba poslat odpoveda naspat	
					   {		
						  // System.out.printf("naslo arp zaznam"); 
						   data[0]=sMAC[0];	//dest mac is source mac of pakcet
						   data[1]=sMAC[1];
						   data[2]=sMAC[2];
						   data[3]=sMAC[3];
						   data[4]=sMAC[4];
						   data[5]=sMAC[5];							   
						   
						   byte[] ipecka = tmp.ip;
						   byte[] macad = tmp.mac;
						   data[6]=macad[0];	//source mac is value from arp_table matching with destIP
						   data[7]=macad[1];
						   data[8]=macad[2];
						   data[9]=macad[3];
						   data[10]=macad[4];
						   data[11]=macad[5];	
						   
						   data[28]=dIP[0];
						   data[29]=dIP[1]; 
						   data[30]=dIP[2];
						   data[31]=dIP[3];

						   data[22]=macad[0];	
						   data[23]=macad[1];	
						   data[24]=macad[2];	
						   data[25]=macad[3];
						   data[26]=macad[4];
						   data[27]=macad[5];
						   
						   data[32]=sMAC[0];	
						   data[33]=sMAC[1];	
						   data[34]=sMAC[2];	
						   data[35]=sMAC[3];	
						   data[36]=sMAC[4];
						   data[37]=sMAC[5];
						   
						   data[38]=sIP[0];
						   data[39]=sIP[1]; 
						   data[40]=sIP[2];
						   data[41]=sIP[3];
						   
						   data[21]=02; //arp reply
						   
						   spacket= asString(data);
				           zasobnik.add(spacket);							
				           
				           if (roz1.sendPacket(data) != Pcap.OK) {  
							      System.err.println(roz1.getErr());  
							    } 
					   }	 
				   }
			}	
			
			if(etherType[1] == 0x00)//IPv4
			{
				
				Ip4 ip = new Ip4();
				byte[] sIP = new byte[4];
				byte[] dIP = new byte[4];
				byte[] sMAC = new byte[6];
				byte[] dMAC = new byte[6];
				
				String sourceIP="";
				String destIP="";
				String destMAC="";
				String sourceMAC="";
				
				
				   sIP = packet.getByteArray(26, 4);
				   sourceIP = org.jnetpcap.packet.format.FormatUtils.ip(sIP);

				   dIP = packet.getByteArray(30, 4);
				   destIP = org.jnetpcap.packet.format.FormatUtils.ip(dIP);
				
				   sMAC = packet.getByteArray(6, 6);
				   sourceMAC = asString(sMAC);

				   dMAC = packet.getByteArray(0, 6);
				   destMAC = asString(dMAC);
				   
	   Arp_riadok tmp = new Arp_riadok();
				   
				   tmp=arp.get(asString(sIP));
				   
				   if (tmp == null){
					   Arp_riadok apom = new Arp_riadok();
						//get mac 
					   apom.mac=sMAC;
						 apom.roz=cislo;
						 apom.typ=1;
						 //get ip 
						 byte[] bytes = sIP;
						 apom.setIp( bytes );
						 arp.put(asString(apom.ip),apom);
					//	 System.out.printf("add %s \n\n",asString(bytes));						 
					   }
				   
				   
				
				 ipType = packet.getByteArray(IP_TYPE_OFFSET, 2); 
				if(ipType[0] == 0x01)//ICMP
				{					
					System.out.printf("	prislo icmp\n");
				}}			
		}
		}
	
	else{
		zasobnik.remove(spacket);
	//	 System.out.printf("			v zasobniku\n");

	}}
	}
	};
	roz1.loop(-1, jpacketHandler, "Quit");
	roz1.close();	
}

private static void info(Pcap roz1,Pcap roz2, Arp_riadok apom, Arp_riadok apom2) { 
	
		while(true){
			
			Scanner in = new Scanner(System.in);
			String vstup = in.nextLine();
			
			if (vstup.equals("show arp"))
			{
			 System.out.printf("			arp tabulka:\n");

		     
			 Enumeration<String> ek = arp.keys();
			 
			 while(ek.hasMoreElements())
			 {
					String key = ek.nextElement();
					
			  	   byte[] mac=arp.get(key).mac;
			  	   byte[] ip = arp.get(key).ip;
			  	   int roz = arp.get(key).roz;			  	   
			  	   int typ=arp.get(key).typ;
				   System.out.printf("arp: %s %s int: %d typ: %d\n", asString(mac), asString(ip),roz,typ);
				 }	           
					System.out.printf("			koniec arp\n\n");
				try
				{
					Thread.sleep(500);
				} catch (InterruptedException ee)
				{
					// TODO Auto-generated catch block
					ee.printStackTrace();
				}
				vstup="";
			}	
		if (vstup.equals("show rt"))
			{
			 System.out.printf("routing table \n");

			 Enumeration<String> ek = rt.keys();
			 
			 while(ek.hasMoreElements())
			 {
					String key = ek.nextElement();
					
			  	   byte[] ip=rt.get(key).ip;
			  	   int mask = rt.get(key).mask;
			  	   int roz = rt.get(key).roz;			  	   
			  	   int typ=rt.get(key).typ;
				   System.out.printf("route: %s/%d int: %d typ: %d\n", asString(ip), mask,roz,typ);
				 }	           
					System.out.printf("koniec routing\n\n");
				try
				{
					Thread.sleep(500);
				} catch (InterruptedException ee)
				{
					// TODO Auto-generated catch block
					ee.printStackTrace();
				}
				vstup="";
			}
			
			if (vstup.equals("ping"))
			{	
				System.out.printf("ip address: ");
				in = new Scanner(System.in);
				 vstup = in.nextLine();
				 
				 System.out.printf("pingam %s\n",vstup);				 
				 //tu zistit podla arp table na ktoru stranu ma posielat arp				 				
				 arp(roz1,roz2,apom, apom2);
				vstup="";
			}
			
			if (vstup.equals("delete arp"))
			{	
				 Iterator<String> keySetItr = arp.keySet().iterator();  
			     
				 Enumeration<String> ek = arp.keys();
				 
				 while(ek.hasMoreElements())
				 {
						String key = ek.nextElement();
						
				  	   int typp=arp.get(key).typ;
				  	
					   if(typp==1)
					   {
						   System.out.printf("delete %s \n\n",asString(arp.get(key).ip));
						   arp.remove(key);
					   }				
					 }
				 System.out.printf("arp deleted \n\n");	
			}		
	}
}
}

 