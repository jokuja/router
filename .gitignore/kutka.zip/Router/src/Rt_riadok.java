
public class Rt_riadok {
	

    byte[] ip; //ip adresa 
	int mask; //maska v tvare cisla
    int roz; //rozhranie
    int typ;//ako naucena d/s
    
    
    public int getMask() {
		return mask;
	}
	public void setMask(int mask) {
		this.mask = mask;
	}
    
    public int getTyp() {
		return typ;
	}
	public void setTyp(int typ) {
		this.typ = typ;
	}
	public byte[] getIp() {
		return ip;
	}
	public void setIp(byte[] ip) {
		this.ip = ip;
	}

	public int getRoz() {
		return roz;
	}
	public void setRoz(int roz) {
		this.roz = roz;
	}
    
    
	
}

