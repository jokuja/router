
public class Arp_riadok {
	
    byte[] mac;
    byte[] ip;
    int typ;
    
    public int getTyp() {
		return typ;
	}
	public void setTyp(int typ) {
		this.typ = typ;
	}
	public byte[] getIp() {
		return ip;
	}
	public void setIp(byte[] ip) {
		this.ip = ip;
	}
	int roz;
    
	public byte[] getMac() {
		return mac;
	}
	public void setMac(byte[] mac) {
		this.mac = mac;
	}
	

	public int getRoz() {
		return roz;
	}
	public void setRoz(int roz) {
		this.roz = roz;
	}
    
    
	
}

