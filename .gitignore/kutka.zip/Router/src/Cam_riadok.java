
public class Cam_riadok {
	
    String mac;
    int port;
    int ttl;
    long vznik;
    
	public long getVznik() {
		return vznik;
	}
	public void setVznik(long vznik) {
		this.vznik = vznik;
	}
	public String getMac() {
		return mac;
	}
	public void setMac(String mac) {
		this.mac = mac;
	}
	public int getPort() {
		return port;
	}
	public void setPort(int port) {
		this.port = port;
	}
	public int getTtl() {
		return ttl;
	}
	public void setTtl(int ttl) {
		this.ttl = ttl;
	}
    
}

